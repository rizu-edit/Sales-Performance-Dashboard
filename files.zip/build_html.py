"""Inject the dataset into dashboard_template.html -> dashboard.html (self-contained)."""
import os, glob, json, pandas as pd
B = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..")
s = pd.concat([pd.read_csv(f) for f in sorted(glob.glob(f"{B}/data/raw/*.csv"))])
s = s.merge(pd.read_csv(f"{B}/data/products.csv")[["Product", "Category", "UnitCost"]], on="Product")
rows = s[["OrderDate", "Region", "Product", "Category", "Units", "UnitPrice", "Discount", "UnitCost", "Returned"]].values.tolist()
html = open(f"{B}/code/dashboard_template.html", encoding="utf-8").read().replace("/*DATA*/[]", json.dumps(rows))
open(f"{B}/dashboard.html", "w", encoding="utf-8").write(html); print(len(rows), "rows embedded")
