"""Generate synthetic sales data: quarterly raw CSVs + a products dimension table."""
import numpy as np, pandas as pd, os
rng = np.random.default_rng(42)
ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "data")

products = pd.DataFrame({
    "Product": ["Aero Laptop 14", "Aero Laptop 16", "Pulse Phone X", "Pulse Phone Mini",
                "Echo Buds Pro", "Echo Speaker", "Vista Monitor 27", "Vista Dock"],
    "Category": ["Computers", "Computers", "Mobile", "Mobile", "Audio", "Audio", "Accessories", "Accessories"],
    "ListPrice": [1099, 1499, 899, 599, 199, 149, 329, 119],
    "UnitCost":  [760, 1020, 590, 380, 85, 62, 210, 54],
})
products.to_csv(f"{ROOT}/products.csv", index=False)

regions = ["North America", "Europe", "APAC", "LATAM", "MEA"]
n = 1800
dates = pd.to_datetime("2025-01-01") + pd.to_timedelta(rng.integers(0, 365, n), unit="D")
prod = rng.choice(products.Product, n, p=[.12, .08, .16, .14, .16, .12, .12, .10])
price = products.set_index("Product").ListPrice
df = pd.DataFrame({
    "OrderDate": dates,
    "Region": rng.choice(regions, n, p=[0.32, 0.28, 0.24, 0.10, 0.06]),
    "Product": prod,
    "Units": rng.integers(1, 9, n),
    "UnitPrice": price.loc[prod].values,
    "Discount": rng.choice([0, 0.05, 0.10, 0.15, 0.20], n, p=[.40, .25, .20, .10, .05]),
    "Returned": (rng.random(n) < 0.04).astype(int),
}).sort_values("OrderDate").reset_index(drop=True)
df.insert(0, "OrderID", [f"ORD-{100000+i}" for i in range(n)])
q = df.OrderDate.dt.quarter
df["OrderDate"] = df.OrderDate.dt.strftime("%Y-%m-%d")
for k in range(1, 5):
    df[q == k].to_csv(f"{ROOT}/raw/sales_2025_Q{k}.csv", index=False)
print(len(df), "rows written")
