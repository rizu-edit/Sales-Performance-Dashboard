# Sales Dashboard Project

Interactive dashboard with **8 KPIs** and **drill-down filters (Region / Product)**, plus **automated data refresh with Power Query**.

## Contents
| Path | What it is |
|---|---|
| `Sales_Dashboard.xlsx` | Excel dashboard: 8 KPI cards, Region + Product dropdown filters, breakdown tables, monthly trend, 3 charts |
| `dashboard.html` | Standalone interactive web version (open in a browser; click bars to drill down) |
| `data/raw/sales_2025_Q1-Q4.csv` | 1,800 synthetic orders (seed 42), one file per quarter |
| `data/products.csv` | Product dimension (category, list price, unit cost) |
| `powerquery/Sales_Query.pq` | M code: folder combine, clean, merge, calculated columns, refresh settings |
| `code/*.py` | Scripts that regenerate the data, workbook and HTML dashboard |

## The 8 KPIs
Total Revenue, Total Profit, Profit Margin, Units Sold, Orders, Avg Order Value, Avg Discount, Return Rate.

## Setting up the Power Query refresh (Excel desktop)
1. Copy `data/` to a fixed folder, e.g. `C:\SalesDashboard\data`.
2. Data > Get Data > Blank Query > Advanced Editor. Create `pFolderPath`, `dimProducts`, `factSales` from `powerquery/Sales_Query.pq` (update the paths).
3. Load `factSales` to a sheet (or the Data Model).
4. Query Properties: tick *Refresh data when opening the file* (and optionally refresh every N minutes).
5. Drop a new CSV in `data/raw/` and click Data > Refresh All: all KPIs update, no manual steps.

Note: the supplied workbook ships with the data pre-loaded and formula-driven KPIs, so it works without Power Query. Power Query itself can only be set up inside desktop Excel, which is why it is provided as M code with steps.

## Rebuild
```
pip install pandas numpy openpyxl
python code/generate_data.py
python code/build_excel.py
python code/build_html.py
```
## Assumptions
Data is synthetic. Revenue = Units x UnitPrice x (1 - Discount); Profit = Revenue - Units x UnitCost; Return Rate = returned orders / orders.

## Resume bullets (fill in your real numbers)
- Designed an interactive Excel/HTML dashboard tracking 8 KPIs with region and product drill-down filters.
- Automated data refresh with Power Query (folder-based combine, merge, cleaning), reducing manual reporting time by [X] hours/week.
