"""Build Sales_Dashboard.xlsx: Data sheet, filterable KPI dashboard (formula-driven), charts."""
import os, pandas as pd, glob
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.worksheet.datavalidation import DataValidation
from openpyxl.chart import BarChart, LineChart, Reference
from openpyxl.worksheet.table import Table, TableStyleInfo

BASE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..")
sales = pd.concat([pd.read_csv(f) for f in sorted(glob.glob(f"{BASE}/data/raw/*.csv"))], ignore_index=True)
prods = pd.read_csv(f"{BASE}/data/products.csv")
sales = sales.merge(prods[["Product", "Category", "UnitCost"]], on="Product", how="left")
sales["OrderDate"] = pd.to_datetime(sales.OrderDate)
N = len(sales); LAST = N + 1

F = "Arial"
NAVY, TEAL, LIGHT = "1F3864", "2E75B6", "EAF1FB"
hdr = Font(name=F, bold=True, color="FFFFFF"); base = Font(name=F)
thin = Side(style="thin", color="BFBFBF"); box = Border(left=thin, right=thin, top=thin, bottom=thin)

wb = Workbook()
# ---------------- Data sheet ----------------
ds = wb.active; ds.title = "Data"
cols = ["OrderID", "OrderDate", "Region", "Product", "Category", "Units", "UnitPrice",
        "Discount", "UnitCost", "Returned", "Revenue", "Profit"]
ds.append(cols)
for i, r in enumerate(sales.itertuples(index=False), start=2):
    ds.append([r.OrderID, r.OrderDate.to_pydatetime(), r.Region, r.Product, r.Category, r.Units,
               r.UnitPrice, r.Discount, r.UnitCost, r.Returned,
               f"=F{i}*G{i}*(1-H{i})", f"=K{i}-F{i}*I{i}"])
for c in ds[1]: c.font = hdr; c.fill = PatternFill("solid", fgColor=NAVY); c.alignment = Alignment(horizontal="center")
for row in ds.iter_rows(min_row=2):
    for c in row: c.font = base
    row[1].number_format = "yyyy-mm-dd"; row[7].number_format = "0%"
    for k in (6, 8, 10, 11): row[k].number_format = "#,##0"
for col, w in zip("ABCDEFGHIJKL", [13, 12, 15, 18, 13, 8, 11, 10, 10, 10, 12, 12]): ds.column_dimensions[col].width = w
ds.freeze_panes = "A2"
t = Table(displayName="factSales", ref=f"A1:L{LAST}")
t.tableStyleInfo = TableStyleInfo(name="TableStyleLight9", showRowStripes=True); ds.add_table(t)

# ---------------- Lists sheet ----------------
ls = wb.create_sheet("Lists")
ls["A1"], ls["B1"] = "Region", "Product"
for i, v in enumerate(["All"] + sorted(sales.Region.unique()), start=2): ls.cell(i, 1, v)
for i, v in enumerate(["All"] + sorted(sales.Product.unique()), start=2): ls.cell(i, 2, v)
for c in ls[1]: c.font = Font(name=F, bold=True)
nreg, nprod = sales.Region.nunique() + 1, sales.Product.nunique() + 1

# ---------------- Dashboard ----------------
d = wb.create_sheet("Dashboard", 0); d.sheet_view.showGridLines = False
for col, w in zip("ABCDEFGHIJ", [3, 22, 20, 20, 20, 3, 22, 14, 14, 14]): d.column_dimensions[col].width = w
d.merge_cells("B1:J1"); d["B1"] = "Sales Performance Dashboard - FY2025"
d["B1"].font = Font(name=F, size=18, bold=True, color="FFFFFF"); d["B1"].fill = PatternFill("solid", fgColor=NAVY)
d["B1"].alignment = Alignment(vertical="center", indent=1); d.row_dimensions[1].height = 34

d["B3"], d["C3"] = "Region filter", "All"; d["B4"], d["C4"] = "Product filter", "All"
d["E3"] = "Select from the yellow dropdowns - every KPI, table and chart recalculates."
d["E3"].font = Font(name=F, italic=True, color="595959")
for r in (3, 4):
    d[f"B{r}"].font = Font(name=F, bold=True)
    d[f"C{r}"].font = Font(name=F, bold=True, color="0000FF"); d[f"C{r}"].fill = PatternFill("solid", fgColor="FFFF00")
    d[f"C{r}"].border = box
v1 = DataValidation(type="list", formula1=f"=Lists!$A$2:$A${nreg+1}", allow_blank=False)
v2 = DataValidation(type="list", formula1=f"=Lists!$B$2:$B${nprod+1}", allow_blank=False)
d.add_data_validation(v1); d.add_data_validation(v2); v1.add("C3"); v2.add("C4")
# helper criteria (wildcard when All)
d["I3"], d["J3"] = "Region crit", '=IF($C$3="All","*",$C$3)'
d["I4"], d["J4"] = "Product crit", '=IF($C$4="All","*",$C$4)'
for c in ("I3", "I4", "J3", "J4"): d[c].font = Font(name=F, color="808080", size=9)

R, P = "Data!$C$2:$C$%d" % LAST, "Data!$D$2:$D$%d" % LAST
rng = lambda col: f"Data!${col}$2:${col}${LAST}"
crit = f'{R},$J$3,{P},$J$4'
kpis = [
    ("Total Revenue",   f"=SUMIFS({rng('K')},{crit})", '$#,##0'),
    ("Total Profit",    f"=SUMIFS({rng('L')},{crit})", '$#,##0'),
    ("Profit Margin",   "=IF(B7=0,0,C7/B7)".replace("B7", "$B$7").replace("C7", "$C$7"), '0.0%'),
    ("Units Sold",      f"=SUMIFS({rng('F')},{crit})", '#,##0'),
    ("Orders",          f"=COUNTIFS({crit})", '#,##0'),
    ("Avg Order Value", None, '$#,##0'),
    ("Avg Discount",    f"=IFERROR(AVERAGEIFS({rng('H')},{crit}),0)", '0.0%'),
    ("Return Rate",     None, '0.0%'),
]
# layout: 2 rows x 4 cards. labels row 6/9, values row 7/10
pos = [("B", 6), ("C", 6), ("D", 6), ("E", 6), ("B", 9), ("C", 9), ("D", 9), ("E", 9)]
refs = {}
for (label, f, fmt), (col, row) in zip(kpis, pos): refs[label] = f"${col}${row+1}"
kpis[2] = ("Profit Margin", f"=IF({refs['Total Revenue']}=0,0,{refs['Total Profit']}/{refs['Total Revenue']})", '0.0%')
kpis[5] = ("Avg Order Value", f"=IF({refs['Orders']}=0,0,{refs['Total Revenue']}/{refs['Orders']})", '$#,##0')
kpis[7] = ("Return Rate", f"=IF({refs['Orders']}=0,0,SUMIFS({rng('J')},{crit})/{refs['Orders']})", '0.0%')
for (label, f, fmt), (col, row) in zip(kpis, pos):
    a, b = d[f"{col}{row}"], d[f"{col}{row+1}"]
    a.value, b.value = label, f; b.number_format = fmt
    a.font = Font(name=F, size=9, bold=True, color="FFFFFF"); a.fill = PatternFill("solid", fgColor=TEAL)
    b.font = Font(name=F, size=16, bold=True, color=NAVY); b.fill = PatternFill("solid", fgColor=LIGHT)
    a.alignment = b.alignment = Alignment(horizontal="center", vertical="center"); a.border = b.border = box
    d.row_dimensions[row + 1].height = 32

def table(r0, title, items, keycol, other_crit):
    d[f"B{r0}"] = title; d[f"B{r0}"].font = Font(name=F, bold=True, size=12, color=NAVY)
    for j, h in enumerate([title.split(" by ")[1], "Revenue", "Profit", "Margin"]):
        c = d.cell(r0 + 1, 2 + j, h); c.font = hdr; c.fill = PatternFill("solid", fgColor=NAVY)
    for i, it in enumerate(items):
        r = r0 + 2 + i
        d.cell(r, 2, it).font = base
        d.cell(r, 3, f"=SUMIFS({rng('K')},{keycol},$B{r},{other_crit})").number_format = '$#,##0'
        d.cell(r, 4, f"=SUMIFS({rng('L')},{keycol},$B{r},{other_crit})").number_format = '$#,##0'
        d.cell(r, 5, f"=IF(C{r}=0,0,D{r}/C{r})").number_format = '0.0%'
        for k in (3, 4, 5): d.cell(r, k).font = base
    return r0 + 2, r0 + 1 + len(items)

regs, prs = sorted(sales.Region.unique()), sorted(sales.Product.unique())
a1, a2 = table(12, "Revenue by Region", regs, R, f"{P},$J$4")      # respects product filter
b1, b2 = table(12 + len(regs) + 3, "Revenue by Product", prs, P, f"{R},$J$3")  # respects region filter

# monthly trend (G:J)
d["G12"] = "Monthly Trend"; d["G12"].font = Font(name=F, bold=True, size=12, color=NAVY)
for j, h in enumerate(["Month", "Revenue", "Profit"]):
    c = d.cell(13, 7 + j, h); c.font = hdr; c.fill = PatternFill("solid", fgColor=NAVY)
D = rng("B")
for m in range(12):
    r = 14 + m
    d.cell(r, 7, pd.Timestamp(2025, m + 1, 1).to_pydatetime()).number_format = "mmm-yy"
    for k, col in ((8, "K"), (9, "L")):
        d.cell(r, k, f'=SUMIFS({rng(col)},{D},">="&$G{r},{D},"<"&EDATE($G{r},1),{crit})').number_format = '$#,##0'
    for k in (7, 8, 9): d.cell(r, k).font = base

# charts
ch = BarChart(); ch.type = "col"; ch.title = "Revenue by Region"; ch.height, ch.width = 7, 12; ch.legend = None
ch.add_data(Reference(d, min_col=3, min_row=13, max_row=a2), titles_from_data=True)
ch.set_categories(Reference(d, min_col=2, min_row=a1, max_row=a2)); d.add_chart(ch, "L3")
ch2 = BarChart(); ch2.type = "bar"; ch2.title = "Revenue by Product"; ch2.height, ch2.width = 8, 12; ch2.legend = None
ch2.add_data(Reference(d, min_col=3, min_row=b1 - 1, max_row=b2), titles_from_data=True)
ch2.set_categories(Reference(d, min_col=2, min_row=b1, max_row=b2)); d.add_chart(ch2, "L18")
lc = LineChart(); lc.title = "Monthly Revenue & Profit"; lc.height, lc.width = 7.5, 16
lc.add_data(Reference(d, min_col=8, max_col=9, min_row=13, max_row=25), titles_from_data=True)
lc.set_categories(Reference(d, min_col=7, min_row=14, max_row=25)); d.add_chart(lc, "G28")

# ---------------- Notes sheet ----------------
nt = wb.create_sheet("Notes")
notes = ["HOW THIS WORKBOOK WORKS",
 "1. 'Data' holds the fact table (named table factSales). Revenue/Profit are formulas.",
 "2. 'Dashboard' filters (yellow cells, blue text) drive all 8 KPIs, both breakdown tables and the trend.",
 "3. Region/Product breakdown tables respect the OTHER filter, giving drill-down behaviour.",
 "4. Automated refresh: replace the Data sheet content with the Power Query output",
 "   (see powerquery/Sales_Query.pq) and set Refresh on open. Formulas read the fixed range A2:L%d;" % LAST,
 "   extend the ranges (or convert to structured refs factSales[Revenue]) if row count grows.",
 "ASSUMPTIONS: data is synthetic (seed 42). Revenue = Units x UnitPrice x (1 - Discount);",
 "Profit = Revenue - Units x UnitCost; Return Rate = returned orders / orders."]
for i, s in enumerate(notes, 1):
    nt.cell(i, 1, s).font = Font(name=F, bold=(i == 1))
nt.column_dimensions["A"].width = 100
wb.save(f"{BASE}/Sales_Dashboard.xlsx"); print("saved", N, "rows")
